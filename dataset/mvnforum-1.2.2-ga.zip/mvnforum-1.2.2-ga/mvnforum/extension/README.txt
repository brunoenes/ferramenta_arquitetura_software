This folder is used to extend mvnForum default. 
You can add your customized file here and this will 
be copied before the compile task

INPORTANT: the files in this folder MUST have directory 
           structure as defined by Servlet specs

Some examples of your customized files that you can put 
in this folder are:

mvnforum.xml 
mvncore.xml
any jsp file that you want to replace the default of mvnForum
any additional .jar library file
